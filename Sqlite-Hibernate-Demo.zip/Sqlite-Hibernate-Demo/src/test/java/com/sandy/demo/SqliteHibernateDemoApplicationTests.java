package com.sandy.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SqliteHibernateDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
